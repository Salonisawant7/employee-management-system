package com.ems.service;

import java.util.Collections;

import org.springframework.security.core.authority.SimpleGrantedAuthority;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import org.springframework.stereotype.Service;

import com.ems.repository.UserRepository;

@Service
public class CustomUserDetailsService
implements UserDetailsService {

    private final UserRepository userRepository;

    public CustomUserDetailsService(
            UserRepository userRepository) {

        this.userRepository = userRepository;
    }

    @Override
    public UserDetails loadUserByUsername(
            String username)
            throws UsernameNotFoundException {

        com.ems.entity.User user = userRepository
                .findByUsername(username)

                .orElseThrow(() ->
                        new UsernameNotFoundException(
                                "User Not Found"));

        return new org.springframework.security.core.userdetails.User(
                user.getUsername(),
                user.getPassword(), 

                Collections.singleton(
                        new SimpleGrantedAuthority("ROLE_USER")
                )
        );
    }
}